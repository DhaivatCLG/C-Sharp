﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace _2DArray
{
    class Program
    {
        static void Main(string[] args)
        {
             int[,] a = new int[3, 3];
            int i, j;

            for (i = 0; i < 3; i++)
            {
                for (j = 0; j < 3; j++)
                {
                    Console.Write("Enter value for "+ i + "*"+ j +" element: ");
                    a[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }
            foreach (int b in a)
            {
                Console.Write(b);
            }
            Console.Read();
        }
    }
}
